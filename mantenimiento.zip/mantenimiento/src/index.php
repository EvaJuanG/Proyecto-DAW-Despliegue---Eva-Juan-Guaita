<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Web en Mantenimiento</title>
    <style>
        body { font-family: sans-serif; text-align: center; padding: 50px; background-color: #f4f4f4; }
        h1 { color: #333; }
        p { color: #666; }
    </style>
</head>
<body>
    <h1>¡Estamos trabajando en ello!</h1>
    <p>La web se encuentra actualmente en mantenimiento. Por favor, vuelve más tarde.</p>
</body>
</html>
